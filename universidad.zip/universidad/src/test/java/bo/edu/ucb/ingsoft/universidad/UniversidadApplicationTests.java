package bo.edu.ucb.ingsoft.universidad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniversidadApplicationTests {

	@Test
	void contextLoads() {
	}

}
